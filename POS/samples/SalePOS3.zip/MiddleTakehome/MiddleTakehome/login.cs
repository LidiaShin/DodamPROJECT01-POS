﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiddleTakehome
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        //Define user name and password variable
        string username;
        string password;
        //Define sql adapter and data table
        SqlDataAdapter adapter;
        DataTable table;
        //Counter for wrong type 
        int WrongInsertCount = 0;
        //Set timer variable
        Timer timer;
        //Set the counter for lock the login form 1 minutes
        int counter = 0;
       
        private void Form1_Load(object sender, EventArgs e)
        {
            TimeLabel.Text = "";
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            
                password = PasswordTextBox.Text;
                username = UserNameTextBox.Text;
                //Connectting to database
                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = @"Data Source = DESKTOP-9GVJKN6; Initial Catalog = Jing; Integrated Security = True";
                adapter = new SqlDataAdapter(@"Select UserName, Password from Users", cn);
                table = new DataTable("Users");
                adapter.Fill(table);


                // SELECT THE USER ROW FROM USERS
                String select_str = "UserName= '" + username + "'";
                DataRow[] row = table.Select(select_str);
                //If the username has the record in database, then check the password

                if (row.Length > 0)
                {
                    for (int i = 0; i < row.Length; i++)
                    {
                        if (row[i]["Password"].ToString() == password)
                        {
                            //Define objects of other form for refer back to login page
                            Cusotmer customer = new Cusotmer();
                            Menu menu = new Menu();
                            Stats stats = new Stats();
                            // define the object of Order
                            Order order = new Order();
                            PasswordTextBox.Text = "";
                            UserNameTextBox.Text = "";
                            order.login = this;
                            order.customer = customer;
                            order.menu = menu;
                            order.stats = stats;
                            order.Show();
                            this.Hide();


                        }
                        else
                        {
                            //if user name correct, password not correct, wrong counter add 1
                            WrongInsertCount++;
                            MessageBox.Show("Password is not correct");
                        }

                    }
                }
                else
                {
                    //if user name is not correct, wrong counter add 1
                    WrongInsertCount++;
                    MessageBox.Show("No username found");
                }



                //if wrong 3 times, block the log in app, set the timer up to 60 minutes
                if (WrongInsertCount == 3)
                {
                    MessageBox.Show("Already tried 3 times, please try after 1 minute");
                    UserNameTextBox.Enabled = false;
                    PasswordTextBox.Enabled = false;
                    EncodeCheckBox.Enabled = false;
                    LoginBtn.Enabled = false;
                    timer = new Timer();
                    timer.Interval = 1000;
                    timer.Enabled = true;
                    timer.Tick += new EventHandler(timer1_Tick);
                }
          
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            counter++;
            TimeLabel.Text = counter.ToString();
            //If get to 1 mintues then enable again
            if (counter == 60)
            {
                timer.Enabled = false;
                counter = 0;
                UserNameTextBox.Enabled = true;
                PasswordTextBox.Enabled = true;
                EncodeCheckBox.Enabled = true;
                LoginBtn.Enabled = true;
                TimeLabel.Text = "";
                WrongInsertCount = 0;
            }
        }

        private void EncodeCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (EncodeCheckBox.Checked)
            {
                PasswordTextBox.UseSystemPasswordChar = true;
            }
            else
            {
                PasswordTextBox.UseSystemPasswordChar = false;
            }
        }
    }
}
