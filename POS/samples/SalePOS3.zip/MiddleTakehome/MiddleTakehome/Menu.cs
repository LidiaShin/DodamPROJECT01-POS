﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace MiddleTakehome
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }
        public Order order;
        public Cusotmer customer;
        public Login login;
        public Stats stats;
        private void Menu_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'jingDataSet1.Product' table. You can move, or remove it, as needed.
            this.productTableAdapter1.Fill(this.jingDataSet1.Product);
            // TODO: This line of code loads data into the 'jingDataSet.Product' table. You can move, or remove it, as needed.
            this.productTableAdapter.Fill(this.jingDataSet.Product);
            // TODO: This line of code loads data into the 'jingDataSet.Product' table. You can move, or remove it, as needed.
            this.productTableAdapter.Fill(this.jingDataSet.Product);
          

        }

        private void OrderBtn_Click(object sender, EventArgs e)
        {
            this.order.dispData();
            this.order.Show();
            this.order.menu = this;
            this.order.customer = this.customer;
            this.order.login = this.login;
            this.order.stats = this.stats;
            this.Hide();
        }

        private void CustomerBtn_Click(object sender, EventArgs e)
        {
            this.customer.Show();
            this.customer.menu = this;
            this.customer.order = this.order;
            this.customer.login = this.login;
            this.customer.stats = this.stats;
            this.Hide();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            this.login.Show();
            this.Hide();
        }

        private void StatsBtn_Click(object sender, EventArgs e)
        {
            this.stats.Show();
            this.stats.login = this.login;
            this.stats.order = this.order;
            this.stats.customer = this.customer;
            this.stats.menu = this;
            this.Hide();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        //Connect with database

        SqlConnection cn = new SqlConnection(@"Data Source = DESKTOP-9GVJKN6; Initial Catalog = Jing; Integrated Security = True");
        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            //add product to the database

            if (addBtn.Checked)
            {
               
                //open connection
                cn.Open();
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                try
                {
                    //Get the image data save to database
                    byte[] imageBt = null;
                    FileStream fstream = new FileStream(this.ImagPath.Text, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fstream);
                    imageBt = br.ReadBytes((int)fstream.Length);
                    cmd.CommandText = "insert into Product values(" + foodidtxtbox.Text + ", '" + CategoryCombox.SelectedItem.ToString() + "', '" + foodnameTextBox.Text + "', " + QuantitytxtBox.Text + ", " + pricetxtBox.Text + ", @IMG"  + ",NULL" + ")";
                    cmd.Parameters.Add(new SqlParameter("@IMG",imageBt));
                    cmd.ExecuteNonQuery();
                   
                }
                catch (Exception)
                {

                    MessageBox.Show("Fail! Please add proper data!");
                }
                cn.Close();
                dispData();
            }
          

            //delete product to the database
          
                if (deleteBtn.Checked)
                {
                   
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    try
                    {
                        cmd.CommandText = "Delete from Product where Product_Id=" + foodidtxtbox.Text.Trim();            
                        cmd.ExecuteNonQuery();                      
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Fail! Please check if choose proper data ! Or the food has been ordered, cannot be deleted!");
                    }
                    cn.Close();
                    dispData();
                }
            //Update product to the database
            if (UpdateBtn.Checked)
            {

                cn.Open();
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                try
                {
                    //Get the image data save to database
                    byte[] imageBt = null;
                    FileStream fstream = new FileStream(this.ImagPath.Text,  FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fstream);
                    imageBt = br.ReadBytes((int)fstream.Length);
                    cmd.CommandText = "Update Product set Product_Category='" + CategoryCombox.SelectedItem.ToString() + "', Product_Name='" + foodnameTextBox.Text + "',Product_Quantity=" + QuantitytxtBox.Text + " ,Purchase_Price=" + pricetxtBox.Text +", Image = @IMG"+ " where Product_Id=" + foodidtxtbox.Text.Trim();
                    cmd.Parameters.Add(new SqlParameter("@IMG", imageBt));
                    cmd.ExecuteNonQuery();

                }
                catch (Exception)
                {
                    MessageBox.Show("Fail! Please check if enter proper data info!");                   
                }
                cn.Close();
                dispData();
            }
        }

        public void intialform() {
            dispData();
            foodidtxtbox.Text = "";
            CategoryCombox.SelectedIndex = -1;
            foodnameTextBox.Text = "";
            QuantitytxtBox.Text = "";
            pricetxtBox.Text = "";
            pictureBox1.Image = null;
            ImagPath.Text = "";
        }
        public void dispData()
        {
            cn.Open();
            SqlCommand cmd = cn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from Product";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            cn.Close();
        }
        //change button to add when choose add radio box
        private void addBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (addBtn.Checked)
            {
                SubmitBtn.Text = "ADD";
            }
            intialform();
            disable_control();
          
            
        }
        //change button to delete when choose delete radio box
        private void deleteBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (deleteBtn.Checked)
            {
                SubmitBtn.Text = "DELETE";
                         
            }
            intialform();
            disable_control();
           
        }
        //change button to update when choose delete radio box
        private void UpdateBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (UpdateBtn.Checked)
            {
                SubmitBtn.Text = "UPDATE";
            }
            intialform();
            disable_control();
           
        }

        public void disable_control() {
            if (deleteBtn.Checked)
            {
                foodidtxtbox.Enabled = false;
                CategoryCombox.Enabled = true;
               foodnameTextBox.Enabled = false;
                QuantitytxtBox.Enabled = false;
                pricetxtBox.Enabled = false;
                UploadPicBtn.Visible = false;
                pictureBox1.Visible = false;
                ImagPath.Visible = false;
            }
            //update operation, disable id only 
            else if (UpdateBtn.Checked)
            {
                foodidtxtbox.Enabled = false;
                CategoryCombox.Enabled = true;
                foodnameTextBox.Enabled = true;
                QuantitytxtBox.Enabled = true;
                pricetxtBox.Enabled = true;
                UploadPicBtn.Enabled = true;
                UploadPicBtn.Visible = true;
                pictureBox1.Visible = true;
                ImagPath.Visible = true;
            }
            else if (addBtn.Checked)
            {
                foodidtxtbox.Enabled = true;
                CategoryCombox.Enabled = true;
                foodnameTextBox.Enabled = true;
                QuantitytxtBox.Enabled = true;
                pricetxtBox.Enabled = true;
                UploadPicBtn.Enabled = true;
                UploadPicBtn.Visible = true;
                pictureBox1.Visible = true;
                ImagPath.Visible = true;
            }
        }
        int index;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //option for delete and add button, enable the text, and retrieve the data from what user choosed
            if (!addBtn.Checked)
            {
                Int32 selectedRowCount = dataGridView1.Rows.GetRowCount(DataGridViewElementStates.Selected);
                if (selectedRowCount > 0)
                {

                    index = dataGridView1.SelectedRows[0].Index;
                    //food id 
                    DataGridViewRow selectedRow = dataGridView1.Rows[index];
                    foodidtxtbox.Text = selectedRow.Cells[0].Value.ToString();
                    //food category combobox
                   CategoryCombox.SelectedIndex = CategoryCombox.Items.IndexOf((selectedRow.Cells[1].Value.ToString()).ToString().Trim());
 
                    //food name
                    foodnameTextBox.Text = selectedRow.Cells[2].Value.ToString();
                    QuantitytxtBox.Text = selectedRow.Cells[3].Value.ToString();
                    pricetxtBox.Text = selectedRow.Cells[4].Value.ToString();
              
                    
                }
            }
          
        }

        private void ControlGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void UploadPicBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "JPG Files(*.jpg)|*.jpg|PNG Files(*.png)|*.png|All Files(*.*)|*.*";
            if (dlg.ShowDialog()==DialogResult.OK)
            {
                string picPath = dlg.FileName.ToString();
                ImagPath.Text = picPath;
                pictureBox1.ImageLocation = picPath;
            }
        }

        private void ImagPath_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
