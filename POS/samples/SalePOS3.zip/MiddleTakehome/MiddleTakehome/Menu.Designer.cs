﻿namespace MiddleTakehome
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.ControlGroupBox = new System.Windows.Forms.GroupBox();
            this.SubmitBtn = new System.Windows.Forms.Button();
            this.nametxtbox = new System.Windows.Forms.GroupBox();
            this.UploadPicBtn = new System.Windows.Forms.Button();
            this.Pricelbl = new System.Windows.Forms.Label();
            this.Quantity = new System.Windows.Forms.Label();
            this.foodnameLbl = new System.Windows.Forms.Label();
            this.CategoryCombox = new System.Windows.Forms.ComboBox();
            this.Category_label = new System.Windows.Forms.Label();
            this.foodnameTextBox = new System.Windows.Forms.TextBox();
            this.pricetxtBox = new System.Windows.Forms.TextBox();
            this.QuantitytxtBox = new System.Windows.Forms.TextBox();
            this.foodidtxtbox = new System.Windows.Forms.TextBox();
            this.Id_Label = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.UpdateBtn = new System.Windows.Forms.RadioButton();
            this.deleteBtn = new System.Windows.Forms.RadioButton();
            this.addBtn = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.MenuGroupBox = new System.Windows.Forms.GroupBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.StatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.LogoutBtn = new System.Windows.Forms.ToolStrip();
            this.OrderBtn = new System.Windows.Forms.ToolStripButton();
            this.CustomerBtn = new System.Windows.Forms.ToolStripButton();
            this.MenuBtn = new System.Windows.Forms.ToolStripButton();
            this.StatsBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.jingDataSet1 = new MiddleTakehome.JingDataSet1();
            this.productBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.productTableAdapter1 = new MiddleTakehome.JingDataSet1TableAdapters.ProductTableAdapter();
            this.productBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imageDataGridViewImageColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.productTableAdapter = new MiddleTakehome.JingDataSetTableAdapters.ProductTableAdapter();
            this.jingDataSet = new MiddleTakehome.JingDataSet();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ImagPath = new System.Windows.Forms.TextBox();
            this.ControlGroupBox.SuspendLayout();
            this.nametxtbox.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.MenuGroupBox.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.LogoutBtn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.jingDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jingDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // ControlGroupBox
            // 
            this.ControlGroupBox.Controls.Add(this.nametxtbox);
            this.ControlGroupBox.Controls.Add(this.groupBox2);
            this.ControlGroupBox.Controls.Add(this.groupBox1);
            this.ControlGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ControlGroupBox.Location = new System.Drawing.Point(127, 0);
            this.ControlGroupBox.Name = "ControlGroupBox";
            this.ControlGroupBox.Size = new System.Drawing.Size(855, 753);
            this.ControlGroupBox.TabIndex = 5;
            this.ControlGroupBox.TabStop = false;
            this.ControlGroupBox.Enter += new System.EventHandler(this.ControlGroupBox_Enter);
            // 
            // SubmitBtn
            // 
            this.SubmitBtn.Location = new System.Drawing.Point(315, 215);
            this.SubmitBtn.Name = "SubmitBtn";
            this.SubmitBtn.Size = new System.Drawing.Size(95, 34);
            this.SubmitBtn.TabIndex = 7;
            this.SubmitBtn.Text = "ADD";
            this.SubmitBtn.UseVisualStyleBackColor = true;
            this.SubmitBtn.Click += new System.EventHandler(this.SubmitBtn_Click);
            // 
            // nametxtbox
            // 
            this.nametxtbox.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.nametxtbox.Controls.Add(this.ImagPath);
            this.nametxtbox.Controls.Add(this.SubmitBtn);
            this.nametxtbox.Controls.Add(this.pictureBox1);
            this.nametxtbox.Controls.Add(this.UploadPicBtn);
            this.nametxtbox.Controls.Add(this.Pricelbl);
            this.nametxtbox.Controls.Add(this.Quantity);
            this.nametxtbox.Controls.Add(this.foodnameLbl);
            this.nametxtbox.Controls.Add(this.CategoryCombox);
            this.nametxtbox.Controls.Add(this.Category_label);
            this.nametxtbox.Controls.Add(this.foodnameTextBox);
            this.nametxtbox.Controls.Add(this.pricetxtBox);
            this.nametxtbox.Controls.Add(this.QuantitytxtBox);
            this.nametxtbox.Controls.Add(this.foodidtxtbox);
            this.nametxtbox.Controls.Add(this.Id_Label);
            this.nametxtbox.Location = new System.Drawing.Point(27, 91);
            this.nametxtbox.Name = "nametxtbox";
            this.nametxtbox.Size = new System.Drawing.Size(797, 267);
            this.nametxtbox.TabIndex = 4;
            this.nametxtbox.TabStop = false;
            // 
            // UploadPicBtn
            // 
            this.UploadPicBtn.Location = new System.Drawing.Point(578, 21);
            this.UploadPicBtn.Name = "UploadPicBtn";
            this.UploadPicBtn.Size = new System.Drawing.Size(116, 29);
            this.UploadPicBtn.TabIndex = 6;
            this.UploadPicBtn.Text = "Upload Picture";
            this.UploadPicBtn.UseVisualStyleBackColor = true;
            this.UploadPicBtn.Click += new System.EventHandler(this.UploadPicBtn_Click);
            // 
            // Pricelbl
            // 
            this.Pricelbl.AutoSize = true;
            this.Pricelbl.Location = new System.Drawing.Point(20, 119);
            this.Pricelbl.Name = "Pricelbl";
            this.Pricelbl.Size = new System.Drawing.Size(48, 17);
            this.Pricelbl.TabIndex = 5;
            this.Pricelbl.Text = "Price: ";
            // 
            // Quantity
            // 
            this.Quantity.AutoSize = true;
            this.Quantity.Location = new System.Drawing.Point(7, 81);
            this.Quantity.Name = "Quantity";
            this.Quantity.Size = new System.Drawing.Size(69, 17);
            this.Quantity.TabIndex = 5;
            this.Quantity.Text = "Quantity: ";
            // 
            // foodnameLbl
            // 
            this.foodnameLbl.AutoSize = true;
            this.foodnameLbl.Location = new System.Drawing.Point(7, 43);
            this.foodnameLbl.Name = "foodnameLbl";
            this.foodnameLbl.Size = new System.Drawing.Size(85, 17);
            this.foodnameLbl.TabIndex = 4;
            this.foodnameLbl.Text = "Food Name:";
            // 
            // CategoryCombox
            // 
            this.CategoryCombox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CategoryCombox.FormattingEnabled = true;
            this.CategoryCombox.Items.AddRange(new object[] {
            "Drinks",
            "Dessert"});
            this.CategoryCombox.Location = new System.Drawing.Point(107, 156);
            this.CategoryCombox.Name = "CategoryCombox";
            this.CategoryCombox.Size = new System.Drawing.Size(121, 24);
            this.CategoryCombox.TabIndex = 3;
            // 
            // Category_label
            // 
            this.Category_label.AutoSize = true;
            this.Category_label.Location = new System.Drawing.Point(7, 159);
            this.Category_label.Name = "Category_label";
            this.Category_label.Size = new System.Drawing.Size(69, 17);
            this.Category_label.TabIndex = 2;
            this.Category_label.Text = "Category:";
            // 
            // foodnameTextBox
            // 
            this.foodnameTextBox.Location = new System.Drawing.Point(107, 43);
            this.foodnameTextBox.Name = "foodnameTextBox";
            this.foodnameTextBox.Size = new System.Drawing.Size(236, 22);
            this.foodnameTextBox.TabIndex = 1;
            // 
            // pricetxtBox
            // 
            this.pricetxtBox.Location = new System.Drawing.Point(107, 119);
            this.pricetxtBox.Name = "pricetxtBox";
            this.pricetxtBox.Size = new System.Drawing.Size(121, 22);
            this.pricetxtBox.TabIndex = 1;
            this.pricetxtBox.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // QuantitytxtBox
            // 
            this.QuantitytxtBox.Location = new System.Drawing.Point(107, 81);
            this.QuantitytxtBox.Name = "QuantitytxtBox";
            this.QuantitytxtBox.Size = new System.Drawing.Size(114, 22);
            this.QuantitytxtBox.TabIndex = 1;
            // 
            // foodidtxtbox
            // 
            this.foodidtxtbox.Location = new System.Drawing.Point(107, 9);
            this.foodidtxtbox.Name = "foodidtxtbox";
            this.foodidtxtbox.Size = new System.Drawing.Size(114, 22);
            this.foodidtxtbox.TabIndex = 1;
            // 
            // Id_Label
            // 
            this.Id_Label.AutoSize = true;
            this.Id_Label.Location = new System.Drawing.Point(7, 10);
            this.Id_Label.Name = "Id_Label";
            this.Id_Label.Size = new System.Drawing.Size(61, 17);
            this.Id_Label.TabIndex = 0;
            this.Id_Label.Text = "Food ID:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.UpdateBtn);
            this.groupBox2.Controls.Add(this.deleteBtn);
            this.groupBox2.Controls.Add(this.addBtn);
            this.groupBox2.Location = new System.Drawing.Point(106, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(615, 56);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            // 
            // UpdateBtn
            // 
            this.UpdateBtn.AutoSize = true;
            this.UpdateBtn.Location = new System.Drawing.Point(427, 21);
            this.UpdateBtn.Name = "UpdateBtn";
            this.UpdateBtn.Size = new System.Drawing.Size(158, 21);
            this.UpdateBtn.TabIndex = 6;
            this.UpdateBtn.TabStop = true;
            this.UpdateBtn.Text = "Update existing food";
            this.UpdateBtn.UseVisualStyleBackColor = true;
            this.UpdateBtn.CheckedChanged += new System.EventHandler(this.UpdateBtn_CheckedChanged);
            // 
            // deleteBtn
            // 
            this.deleteBtn.AutoSize = true;
            this.deleteBtn.Location = new System.Drawing.Point(206, 21);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(153, 21);
            this.deleteBtn.TabIndex = 5;
            this.deleteBtn.TabStop = true;
            this.deleteBtn.Text = "Delete existing food";
            this.deleteBtn.UseVisualStyleBackColor = true;
            this.deleteBtn.CheckedChanged += new System.EventHandler(this.deleteBtn_CheckedChanged);
            // 
            // addBtn
            // 
            this.addBtn.AutoSize = true;
            this.addBtn.Checked = true;
            this.addBtn.Location = new System.Drawing.Point(28, 21);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(115, 21);
            this.addBtn.TabIndex = 4;
            this.addBtn.TabStop = true;
            this.addBtn.Text = "Add new food";
            this.addBtn.UseVisualStyleBackColor = true;
            this.addBtn.CheckedChanged += new System.EventHandler(this.addBtn_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox1.Location = new System.Drawing.Point(3, 346);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(849, 404);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.imageDataGridViewImageColumn});
            this.dataGridView1.DataSource = this.productBindingSource4;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(843, 383);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // MenuGroupBox
            // 
            this.MenuGroupBox.Controls.Add(this.statusStrip1);
            this.MenuGroupBox.Controls.Add(this.LogoutBtn);
            this.MenuGroupBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.MenuGroupBox.Location = new System.Drawing.Point(0, 0);
            this.MenuGroupBox.Name = "MenuGroupBox";
            this.MenuGroupBox.Size = new System.Drawing.Size(127, 753);
            this.MenuGroupBox.TabIndex = 4;
            this.MenuGroupBox.TabStop = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StatusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(3, 725);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(121, 25);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // StatusLabel
            // 
            this.StatusLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.StatusLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.StatusLabel.Name = "StatusLabel";
            this.StatusLabel.Size = new System.Drawing.Size(46, 20);
            this.StatusLabel.Text = "Menu";
            // 
            // LogoutBtn
            // 
            this.LogoutBtn.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.LogoutBtn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OrderBtn,
            this.CustomerBtn,
            this.MenuBtn,
            this.StatsBtn,
            this.toolStripButton4});
            this.LogoutBtn.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.LogoutBtn.Location = new System.Drawing.Point(3, 18);
            this.LogoutBtn.Name = "LogoutBtn";
            this.LogoutBtn.Size = new System.Drawing.Size(121, 446);
            this.LogoutBtn.TabIndex = 0;
            this.LogoutBtn.Text = "toolStrip1";
            // 
            // OrderBtn
            // 
            this.OrderBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.OrderBtn.Image = ((System.Drawing.Image)(resources.GetObject("OrderBtn.Image")));
            this.OrderBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.OrderBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.OrderBtn.Name = "OrderBtn";
            this.OrderBtn.Size = new System.Drawing.Size(119, 84);
            this.OrderBtn.Text = "ORDER";
            this.OrderBtn.Click += new System.EventHandler(this.OrderBtn_Click);
            // 
            // CustomerBtn
            // 
            this.CustomerBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.CustomerBtn.Image = ((System.Drawing.Image)(resources.GetObject("CustomerBtn.Image")));
            this.CustomerBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CustomerBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.CustomerBtn.Name = "CustomerBtn";
            this.CustomerBtn.Size = new System.Drawing.Size(119, 84);
            this.CustomerBtn.Text = "CUSTOMER";
            this.CustomerBtn.Click += new System.EventHandler(this.CustomerBtn_Click);
            // 
            // MenuBtn
            // 
            this.MenuBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.MenuBtn.Image = ((System.Drawing.Image)(resources.GetObject("MenuBtn.Image")));
            this.MenuBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MenuBtn.Name = "MenuBtn";
            this.MenuBtn.Size = new System.Drawing.Size(119, 84);
            this.MenuBtn.Text = "MENU";
            // 
            // StatsBtn
            // 
            this.StatsBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.StatsBtn.Image = ((System.Drawing.Image)(resources.GetObject("StatsBtn.Image")));
            this.StatsBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.StatsBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StatsBtn.Name = "StatsBtn";
            this.StatsBtn.Size = new System.Drawing.Size(119, 84);
            this.StatsBtn.Text = "STATS";
            this.StatsBtn.Click += new System.EventHandler(this.StatsBtn_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(119, 84);
            this.toolStripButton4.Text = "LOGOUT";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // jingDataSet1
            // 
            this.jingDataSet1.DataSetName = "JingDataSet1";
            this.jingDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productBindingSource2
            // 
            this.productBindingSource2.DataMember = "Product";
            this.productBindingSource2.DataSource = this.jingDataSet1;
            // 
            // productTableAdapter1
            // 
            this.productTableAdapter1.ClearBeforeFill = true;
            // 
            // productBindingSource4
            // 
            this.productBindingSource4.DataMember = "Product";
            this.productBindingSource4.DataSource = this.jingDataSet1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Product_Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Product_Id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Product_Category";
            this.dataGridViewTextBoxColumn2.HeaderText = "Product_Category";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Product_Name";
            this.dataGridViewTextBoxColumn3.HeaderText = "Product_Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Product_Quantity";
            this.dataGridViewTextBoxColumn4.HeaderText = "Product_Quantity";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Purchase_Price";
            this.dataGridViewTextBoxColumn5.HeaderText = "Purchase_Price";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // imageDataGridViewImageColumn
            // 
            this.imageDataGridViewImageColumn.DataPropertyName = "Image";
            this.imageDataGridViewImageColumn.HeaderText = "Image";
            this.imageDataGridViewImageColumn.Name = "imageDataGridViewImageColumn";
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // jingDataSet
            // 
            this.jingDataSet.DataSetName = "JingDataSet";
            this.jingDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.jingDataSet;
            // 
            // productBindingSource3
            // 
            this.productBindingSource3.DataMember = "Product";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(559, 93);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(155, 110);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // ImagPath
            // 
            this.ImagPath.Location = new System.Drawing.Point(559, 56);
            this.ImagPath.Name = "ImagPath";
            this.ImagPath.Size = new System.Drawing.Size(155, 22);
            this.ImagPath.TabIndex = 8;
            this.ImagPath.TextChanged += new System.EventHandler(this.ImagPath_TextChanged);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 753);
            this.Controls.Add(this.ControlGroupBox);
            this.Controls.Add(this.MenuGroupBox);
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.ControlGroupBox.ResumeLayout(false);
            this.nametxtbox.ResumeLayout(false);
            this.nametxtbox.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.MenuGroupBox.ResumeLayout(false);
            this.MenuGroupBox.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.LogoutBtn.ResumeLayout(false);
            this.LogoutBtn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.jingDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jingDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox ControlGroupBox;
        private System.Windows.Forms.GroupBox MenuGroupBox;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel StatusLabel;
        private System.Windows.Forms.ToolStrip LogoutBtn;
        private System.Windows.Forms.ToolStripButton OrderBtn;
        private System.Windows.Forms.ToolStripButton CustomerBtn;
        private System.Windows.Forms.ToolStripButton MenuBtn;
        private System.Windows.Forms.ToolStripButton StatsBtn;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productCategoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productQuantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchasePriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox nametxtbox;
        private System.Windows.Forms.Label Quantity;
        private System.Windows.Forms.Label foodnameLbl;
        private System.Windows.Forms.ComboBox CategoryCombox;
        private System.Windows.Forms.Label Category_label;
        private System.Windows.Forms.TextBox foodnameTextBox;
        private System.Windows.Forms.TextBox QuantitytxtBox;
        private System.Windows.Forms.TextBox foodidtxtbox;
        private System.Windows.Forms.Label Id_Label;
        private System.Windows.Forms.Label Pricelbl;
        private System.Windows.Forms.TextBox pricetxtBox;
        private System.Windows.Forms.Button SubmitBtn;
        private System.Windows.Forms.Button UploadPicBtn;
        private System.Windows.Forms.RadioButton addBtn;
        private System.Windows.Forms.RadioButton UpdateBtn;
        private System.Windows.Forms.RadioButton deleteBtn;
        private JingDataSet1 jingDataSet1;
        private System.Windows.Forms.BindingSource productBindingSource2;
        private JingDataSet1TableAdapters.ProductTableAdapter productTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewImageColumn imageDataGridViewImageColumn;
        private System.Windows.Forms.BindingSource productBindingSource4;
        private JingDataSetTableAdapters.ProductTableAdapter productTableAdapter;
        private JingDataSet jingDataSet;
        private System.Windows.Forms.BindingSource productBindingSource;
        private System.Windows.Forms.BindingSource productBindingSource3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox ImagPath;
    }
}