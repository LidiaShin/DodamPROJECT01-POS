﻿namespace MiddleTakehome
{
    partial class Cusotmer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cusotmer));
            this.ControlGroupBox = new System.Windows.Forms.GroupBox();
            this.MenuGroupBox = new System.Windows.Forms.GroupBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.StatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.LogoutBtn = new System.Windows.Forms.ToolStrip();
            this.OrderBtn = new System.Windows.Forms.ToolStripButton();
            this.CustomerBtn = new System.Windows.Forms.ToolStripButton();
            this.MenuBtn = new System.Windows.Forms.ToolStripButton();
            this.StatsBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.nametxtbox = new System.Windows.Forms.GroupBox();
            this.Id_Label = new System.Windows.Forms.Label();
            this.idtxtbox = new System.Windows.Forms.TextBox();
            this.CitytxtBox = new System.Windows.Forms.TextBox();
            this.PhoneTxtBox = new System.Windows.Forms.TextBox();
            this.addtxtBox = new System.Windows.Forms.TextBox();
            this.CustomerNameTextBox = new System.Windows.Forms.TextBox();
            this.Category_label = new System.Windows.Forms.Label();
            this.foodnameLbl = new System.Windows.Forms.Label();
            this.Quantity = new System.Windows.Forms.Label();
            this.Pricelbl = new System.Windows.Forms.Label();
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.SearchTxtBox = new System.Windows.Forms.TextBox();
            this.SearchBtn = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.InsertBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ControlGroupBox.SuspendLayout();
            this.MenuGroupBox.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.LogoutBtn.SuspendLayout();
            this.nametxtbox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // ControlGroupBox
            // 
            this.ControlGroupBox.Controls.Add(this.label1);
            this.ControlGroupBox.Controls.Add(this.groupBox1);
            this.ControlGroupBox.Controls.Add(this.nametxtbox);
            this.ControlGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ControlGroupBox.Location = new System.Drawing.Point(127, 0);
            this.ControlGroupBox.Name = "ControlGroupBox";
            this.ControlGroupBox.Size = new System.Drawing.Size(855, 753);
            this.ControlGroupBox.TabIndex = 3;
            this.ControlGroupBox.TabStop = false;
            // 
            // MenuGroupBox
            // 
            this.MenuGroupBox.Controls.Add(this.statusStrip1);
            this.MenuGroupBox.Controls.Add(this.LogoutBtn);
            this.MenuGroupBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.MenuGroupBox.Location = new System.Drawing.Point(0, 0);
            this.MenuGroupBox.Name = "MenuGroupBox";
            this.MenuGroupBox.Size = new System.Drawing.Size(127, 753);
            this.MenuGroupBox.TabIndex = 2;
            this.MenuGroupBox.TabStop = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StatusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(3, 725);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(121, 25);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // StatusLabel
            // 
            this.StatusLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.StatusLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.StatusLabel.Name = "StatusLabel";
            this.StatusLabel.Size = new System.Drawing.Size(72, 20);
            this.StatusLabel.Text = "Customer";
            // 
            // LogoutBtn
            // 
            this.LogoutBtn.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.LogoutBtn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OrderBtn,
            this.CustomerBtn,
            this.MenuBtn,
            this.StatsBtn,
            this.toolStripButton4});
            this.LogoutBtn.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.LogoutBtn.Location = new System.Drawing.Point(3, 18);
            this.LogoutBtn.Name = "LogoutBtn";
            this.LogoutBtn.Size = new System.Drawing.Size(121, 446);
            this.LogoutBtn.TabIndex = 0;
            this.LogoutBtn.Text = "toolStrip1";
            // 
            // OrderBtn
            // 
            this.OrderBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.OrderBtn.Image = ((System.Drawing.Image)(resources.GetObject("OrderBtn.Image")));
            this.OrderBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.OrderBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.OrderBtn.Name = "OrderBtn";
            this.OrderBtn.Size = new System.Drawing.Size(119, 84);
            this.OrderBtn.Text = "ORDER";
            this.OrderBtn.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // CustomerBtn
            // 
            this.CustomerBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.CustomerBtn.Image = ((System.Drawing.Image)(resources.GetObject("CustomerBtn.Image")));
            this.CustomerBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CustomerBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.CustomerBtn.Name = "CustomerBtn";
            this.CustomerBtn.Size = new System.Drawing.Size(119, 84);
            this.CustomerBtn.Text = "CUSTOMER";
            // 
            // MenuBtn
            // 
            this.MenuBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.MenuBtn.Image = ((System.Drawing.Image)(resources.GetObject("MenuBtn.Image")));
            this.MenuBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MenuBtn.Name = "MenuBtn";
            this.MenuBtn.Size = new System.Drawing.Size(119, 84);
            this.MenuBtn.Text = "MENU";
            this.MenuBtn.Click += new System.EventHandler(this.MenuBtn_Click);
            // 
            // StatsBtn
            // 
            this.StatsBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.StatsBtn.Image = ((System.Drawing.Image)(resources.GetObject("StatsBtn.Image")));
            this.StatsBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.StatsBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StatsBtn.Name = "StatsBtn";
            this.StatsBtn.Size = new System.Drawing.Size(119, 84);
            this.StatsBtn.Text = "STATS";
            this.StatsBtn.Click += new System.EventHandler(this.StatsBtn_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(119, 84);
            this.toolStripButton4.Text = "LOGOUT";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // nametxtbox
            // 
            this.nametxtbox.BackColor = System.Drawing.SystemColors.Control;
            this.nametxtbox.Controls.Add(this.InsertBtn);
            this.nametxtbox.Controls.Add(this.button1);
            this.nametxtbox.Controls.Add(this.DeleteBtn);
            this.nametxtbox.Controls.Add(this.Pricelbl);
            this.nametxtbox.Controls.Add(this.Quantity);
            this.nametxtbox.Controls.Add(this.foodnameLbl);
            this.nametxtbox.Controls.Add(this.Category_label);
            this.nametxtbox.Controls.Add(this.CustomerNameTextBox);
            this.nametxtbox.Controls.Add(this.addtxtBox);
            this.nametxtbox.Controls.Add(this.PhoneTxtBox);
            this.nametxtbox.Controls.Add(this.CitytxtBox);
            this.nametxtbox.Controls.Add(this.idtxtbox);
            this.nametxtbox.Controls.Add(this.Id_Label);
            this.nametxtbox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.nametxtbox.Location = new System.Drawing.Point(3, 447);
            this.nametxtbox.Name = "nametxtbox";
            this.nametxtbox.Size = new System.Drawing.Size(849, 303);
            this.nametxtbox.TabIndex = 6;
            this.nametxtbox.TabStop = false;
            // 
            // Id_Label
            // 
            this.Id_Label.AutoSize = true;
            this.Id_Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Id_Label.Location = new System.Drawing.Point(40, 46);
            this.Id_Label.Name = "Id_Label";
            this.Id_Label.Size = new System.Drawing.Size(109, 20);
            this.Id_Label.TabIndex = 0;
            this.Id_Label.Text = "Customer ID:";
            // 
            // idtxtbox
            // 
            this.idtxtbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idtxtbox.Location = new System.Drawing.Point(182, 46);
            this.idtxtbox.Name = "idtxtbox";
            this.idtxtbox.Size = new System.Drawing.Size(220, 27);
            this.idtxtbox.TabIndex = 1;
            // 
            // CitytxtBox
            // 
            this.CitytxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CitytxtBox.Location = new System.Drawing.Point(112, 95);
            this.CitytxtBox.Name = "CitytxtBox";
            this.CitytxtBox.Size = new System.Drawing.Size(290, 27);
            this.CitytxtBox.TabIndex = 1;
            this.CitytxtBox.TextChanged += new System.EventHandler(this.CitytxtBox_TextChanged);
            // 
            // PhoneTxtBox
            // 
            this.PhoneTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneTxtBox.Location = new System.Drawing.Point(188, 145);
            this.PhoneTxtBox.Name = "PhoneTxtBox";
            this.PhoneTxtBox.Size = new System.Drawing.Size(214, 27);
            this.PhoneTxtBox.TabIndex = 1;
            this.PhoneTxtBox.TextChanged += new System.EventHandler(this.CitytxtBox_TextChanged);
            // 
            // addtxtBox
            // 
            this.addtxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addtxtBox.Location = new System.Drawing.Point(571, 95);
            this.addtxtBox.Name = "addtxtBox";
            this.addtxtBox.Size = new System.Drawing.Size(257, 27);
            this.addtxtBox.TabIndex = 1;
            // 
            // CustomerNameTextBox
            // 
            this.CustomerNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerNameTextBox.Location = new System.Drawing.Point(616, 46);
            this.CustomerNameTextBox.Name = "CustomerNameTextBox";
            this.CustomerNameTextBox.Size = new System.Drawing.Size(212, 27);
            this.CustomerNameTextBox.TabIndex = 1;
            // 
            // Category_label
            // 
            this.Category_label.AutoSize = true;
            this.Category_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Category_label.Location = new System.Drawing.Point(40, 152);
            this.Category_label.Name = "Category_label";
            this.Category_label.Size = new System.Drawing.Size(124, 20);
            this.Category_label.TabIndex = 2;
            this.Category_label.Text = "Contact Phone:";
            // 
            // foodnameLbl
            // 
            this.foodnameLbl.AutoSize = true;
            this.foodnameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.foodnameLbl.Location = new System.Drawing.Point(450, 46);
            this.foodnameLbl.Name = "foodnameLbl";
            this.foodnameLbl.Size = new System.Drawing.Size(136, 20);
            this.foodnameLbl.TabIndex = 4;
            this.foodnameLbl.Text = "Customer Name:";
            this.foodnameLbl.Click += new System.EventHandler(this.foodnameLbl_Click);
            // 
            // Quantity
            // 
            this.Quantity.AutoSize = true;
            this.Quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Quantity.Location = new System.Drawing.Point(40, 98);
            this.Quantity.Name = "Quantity";
            this.Quantity.Size = new System.Drawing.Size(48, 20);
            this.Quantity.TabIndex = 5;
            this.Quantity.Text = "City: ";
            this.Quantity.Click += new System.EventHandler(this.Quantity_Click);
            // 
            // Pricelbl
            // 
            this.Pricelbl.AutoSize = true;
            this.Pricelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pricelbl.Location = new System.Drawing.Point(460, 102);
            this.Pricelbl.Name = "Pricelbl";
            this.Pricelbl.Size = new System.Drawing.Size(81, 20);
            this.Pricelbl.TabIndex = 5;
            this.Pricelbl.Text = "Address: ";
            this.Pricelbl.Click += new System.EventHandler(this.Pricelbl_Click);
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.DeleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteBtn.Location = new System.Drawing.Point(371, 230);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(95, 34);
            this.DeleteBtn.TabIndex = 7;
            this.DeleteBtn.Text = "Delete";
            this.DeleteBtn.UseVisualStyleBackColor = false;
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // SearchTxtBox
            // 
            this.SearchTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchTxtBox.Location = new System.Drawing.Point(7, 25);
            this.SearchTxtBox.Name = "SearchTxtBox";
            this.SearchTxtBox.Size = new System.Drawing.Size(190, 27);
            this.SearchTxtBox.TabIndex = 8;
            // 
            // SearchBtn
            // 
            this.SearchBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchBtn.Location = new System.Drawing.Point(221, 21);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(228, 34);
            this.SearchBtn.TabIndex = 9;
            this.SearchBtn.Text = "Search By Cutomer ID";
            this.SearchBtn.UseVisualStyleBackColor = true;
            this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.SearchBtn);
            this.groupBox1.Controls.Add(this.SearchTxtBox);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(3, 18);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(849, 392);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(7, 66);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(833, 320);
            this.dataGridView1.TabIndex = 10;
            // 
            // InsertBtn
            // 
            this.InsertBtn.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.InsertBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InsertBtn.Location = new System.Drawing.Point(83, 230);
            this.InsertBtn.Name = "InsertBtn";
            this.InsertBtn.Size = new System.Drawing.Size(95, 34);
            this.InsertBtn.TabIndex = 7;
            this.InsertBtn.Text = "Insert";
            this.InsertBtn.UseVisualStyleBackColor = false;
            this.InsertBtn.Click += new System.EventHandler(this.InsertBtn_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(676, 230);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 34);
            this.button1.TabIndex = 7;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(7, 427);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(305, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "*** For Delete, please only provide Customer ID";
            // 
            // Cusotmer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 753);
            this.Controls.Add(this.ControlGroupBox);
            this.Controls.Add(this.MenuGroupBox);
            this.Name = "Cusotmer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cusotmer";
            this.Load += new System.EventHandler(this.Cusotmer_Load);
            this.ControlGroupBox.ResumeLayout(false);
            this.ControlGroupBox.PerformLayout();
            this.MenuGroupBox.ResumeLayout(false);
            this.MenuGroupBox.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.LogoutBtn.ResumeLayout(false);
            this.LogoutBtn.PerformLayout();
            this.nametxtbox.ResumeLayout(false);
            this.nametxtbox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox ControlGroupBox;
        private System.Windows.Forms.GroupBox MenuGroupBox;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel StatusLabel;
        private System.Windows.Forms.ToolStrip LogoutBtn;
        private System.Windows.Forms.ToolStripButton OrderBtn;
        private System.Windows.Forms.ToolStripButton CustomerBtn;
        private System.Windows.Forms.ToolStripButton MenuBtn;
        private System.Windows.Forms.ToolStripButton StatsBtn;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button SearchBtn;
        private System.Windows.Forms.TextBox SearchTxtBox;
        private System.Windows.Forms.GroupBox nametxtbox;
        private System.Windows.Forms.Button DeleteBtn;
        private System.Windows.Forms.Label Pricelbl;
        private System.Windows.Forms.Label Quantity;
        private System.Windows.Forms.Label foodnameLbl;
        private System.Windows.Forms.Label Category_label;
        private System.Windows.Forms.TextBox CustomerNameTextBox;
        private System.Windows.Forms.TextBox addtxtBox;
        private System.Windows.Forms.TextBox PhoneTxtBox;
        private System.Windows.Forms.TextBox CitytxtBox;
        private System.Windows.Forms.TextBox idtxtbox;
        private System.Windows.Forms.Label Id_Label;
        private System.Windows.Forms.Button InsertBtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
    }
}