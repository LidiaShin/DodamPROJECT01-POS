﻿namespace MiddleTakehome
{
    partial class Stats
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Stats));
            this.ControlGroupBox = new System.Windows.Forms.GroupBox();
            this.MenuGroupBox = new System.Windows.Forms.GroupBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.StatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.LogoutBtn = new System.Windows.Forms.ToolStrip();
            this.OrderBtn = new System.Windows.Forms.ToolStripButton();
            this.CustomerBtn = new System.Windows.Forms.ToolStripButton();
            this.MenuBtn = new System.Windows.Forms.ToolStripButton();
            this.StatsBtn = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.label1 = new System.Windows.Forms.Label();
            this.SearchIDTxtBox = new System.Windows.Forms.TextBox();
            this.SearchBtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.productidTxtBox = new System.Windows.Forms.TextBox();
            this.search2btn = new System.Windows.Forms.Button();
            this.ControlGroupBox.SuspendLayout();
            this.MenuGroupBox.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.LogoutBtn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // ControlGroupBox
            // 
            this.ControlGroupBox.Controls.Add(this.search2btn);
            this.ControlGroupBox.Controls.Add(this.button2);
            this.ControlGroupBox.Controls.Add(this.button1);
            this.ControlGroupBox.Controls.Add(this.dataGridView1);
            this.ControlGroupBox.Controls.Add(this.SearchBtn);
            this.ControlGroupBox.Controls.Add(this.productidTxtBox);
            this.ControlGroupBox.Controls.Add(this.SearchIDTxtBox);
            this.ControlGroupBox.Controls.Add(this.label2);
            this.ControlGroupBox.Controls.Add(this.label1);
            this.ControlGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ControlGroupBox.Location = new System.Drawing.Point(127, 0);
            this.ControlGroupBox.Name = "ControlGroupBox";
            this.ControlGroupBox.Size = new System.Drawing.Size(855, 753);
            this.ControlGroupBox.TabIndex = 7;
            this.ControlGroupBox.TabStop = false;
            // 
            // MenuGroupBox
            // 
            this.MenuGroupBox.Controls.Add(this.statusStrip1);
            this.MenuGroupBox.Controls.Add(this.LogoutBtn);
            this.MenuGroupBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.MenuGroupBox.Location = new System.Drawing.Point(0, 0);
            this.MenuGroupBox.Name = "MenuGroupBox";
            this.MenuGroupBox.Size = new System.Drawing.Size(127, 753);
            this.MenuGroupBox.TabIndex = 6;
            this.MenuGroupBox.TabStop = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StatusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(3, 725);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(121, 25);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // StatusLabel
            // 
            this.StatusLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.StatusLabel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.StatusLabel.Name = "StatusLabel";
            this.StatusLabel.Size = new System.Drawing.Size(41, 20);
            this.StatusLabel.Text = "Stats";
            // 
            // LogoutBtn
            // 
            this.LogoutBtn.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.LogoutBtn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OrderBtn,
            this.CustomerBtn,
            this.MenuBtn,
            this.StatsBtn,
            this.toolStripButton4});
            this.LogoutBtn.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.LogoutBtn.Location = new System.Drawing.Point(3, 18);
            this.LogoutBtn.Name = "LogoutBtn";
            this.LogoutBtn.Size = new System.Drawing.Size(121, 446);
            this.LogoutBtn.TabIndex = 0;
            this.LogoutBtn.Text = "toolStrip1";
            // 
            // OrderBtn
            // 
            this.OrderBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.OrderBtn.Image = ((System.Drawing.Image)(resources.GetObject("OrderBtn.Image")));
            this.OrderBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.OrderBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.OrderBtn.Name = "OrderBtn";
            this.OrderBtn.Size = new System.Drawing.Size(119, 84);
            this.OrderBtn.Text = "ORDER";
            // 
            // CustomerBtn
            // 
            this.CustomerBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.CustomerBtn.Image = ((System.Drawing.Image)(resources.GetObject("CustomerBtn.Image")));
            this.CustomerBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.CustomerBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.CustomerBtn.Name = "CustomerBtn";
            this.CustomerBtn.Size = new System.Drawing.Size(119, 84);
            this.CustomerBtn.Text = "CUSTOMER";
            this.CustomerBtn.Click += new System.EventHandler(this.CustomerBtn_Click);
            // 
            // MenuBtn
            // 
            this.MenuBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.MenuBtn.Image = ((System.Drawing.Image)(resources.GetObject("MenuBtn.Image")));
            this.MenuBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MenuBtn.Name = "MenuBtn";
            this.MenuBtn.Size = new System.Drawing.Size(119, 84);
            this.MenuBtn.Text = "MENU";
            this.MenuBtn.Click += new System.EventHandler(this.MenuBtn_Click);
            // 
            // StatsBtn
            // 
            this.StatsBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.StatsBtn.Image = ((System.Drawing.Image)(resources.GetObject("StatsBtn.Image")));
            this.StatsBtn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.StatsBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.StatsBtn.Name = "StatsBtn";
            this.StatsBtn.Size = new System.Drawing.Size(119, 84);
            this.StatsBtn.Text = "STATS";
            this.StatsBtn.Click += new System.EventHandler(this.StatsBtn_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(119, 84);
            this.toolStripButton4.Text = "LOGOUT";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Order By Customer ID:";
            // 
            // SearchIDTxtBox
            // 
            this.SearchIDTxtBox.Location = new System.Drawing.Point(216, 38);
            this.SearchIDTxtBox.Name = "SearchIDTxtBox";
            this.SearchIDTxtBox.Size = new System.Drawing.Size(208, 22);
            this.SearchIDTxtBox.TabIndex = 1;
            this.SearchIDTxtBox.TextChanged += new System.EventHandler(this.SearchIDTxtBox_TextChanged);
            // 
            // SearchBtn
            // 
            this.SearchBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchBtn.Location = new System.Drawing.Point(430, 33);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(82, 35);
            this.SearchBtn.TabIndex = 2;
            this.SearchBtn.Text = "Search";
            this.SearchBtn.UseVisualStyleBackColor = true;
            this.SearchBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(32, 159);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(776, 546);
            this.dataGridView1.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(533, 33);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(275, 35);
            this.button1.TabIndex = 4;
            this.button1.Text = "Display All Orders By Customers";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(533, 82);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(275, 36);
            this.button2.TabIndex = 5;
            this.button2.Text = "Dsiplay All orders by Products";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(43, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Order By Product ID:";
            // 
            // productidTxtBox
            // 
            this.productidTxtBox.Location = new System.Drawing.Point(216, 90);
            this.productidTxtBox.Name = "productidTxtBox";
            this.productidTxtBox.Size = new System.Drawing.Size(208, 22);
            this.productidTxtBox.TabIndex = 1;
            this.productidTxtBox.TextChanged += new System.EventHandler(this.SearchIDTxtBox_TextChanged);
            // 
            // search2btn
            // 
            this.search2btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search2btn.Location = new System.Drawing.Point(430, 82);
            this.search2btn.Name = "search2btn";
            this.search2btn.Size = new System.Drawing.Size(81, 36);
            this.search2btn.TabIndex = 6;
            this.search2btn.Text = "Search";
            this.search2btn.UseVisualStyleBackColor = true;
            this.search2btn.Click += new System.EventHandler(this.search2btn_Click);
            // 
            // Stats
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 753);
            this.Controls.Add(this.ControlGroupBox);
            this.Controls.Add(this.MenuGroupBox);
            this.Name = "Stats";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Stats";
            this.Load += new System.EventHandler(this.Stats_Load);
            this.ControlGroupBox.ResumeLayout(false);
            this.ControlGroupBox.PerformLayout();
            this.MenuGroupBox.ResumeLayout(false);
            this.MenuGroupBox.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.LogoutBtn.ResumeLayout(false);
            this.LogoutBtn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox ControlGroupBox;
        private System.Windows.Forms.GroupBox MenuGroupBox;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel StatusLabel;
        private System.Windows.Forms.ToolStrip LogoutBtn;
        private System.Windows.Forms.ToolStripButton OrderBtn;
        private System.Windows.Forms.ToolStripButton CustomerBtn;
        private System.Windows.Forms.ToolStripButton MenuBtn;
        private System.Windows.Forms.ToolStripButton StatsBtn;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button SearchBtn;
        private System.Windows.Forms.TextBox SearchIDTxtBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox productidTxtBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button search2btn;
    }
}