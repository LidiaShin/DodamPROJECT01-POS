﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiddleTakehome
{
    public partial class Cusotmer : Form
    {
        public Cusotmer()
        {
            InitializeComponent();
        }
       public Order order;
       public Login login;
        public Menu menu;
        public Stats stats;
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.order.dispCustomer();
            this.order.Show();
            this.order.customer = this;
            this.order.menu = this.menu;
            this.order.login = this.login;
            this.order.stats = this.stats;
            this.Hide();

        }

     

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            this.login.Show();
            this.Hide();
        }

        private void MenuBtn_Click(object sender, EventArgs e)
        {
            this.menu.Show();
            this.menu.customer = this;
            this.menu.order = this.order;
            this.menu.login = this.login;
            this.menu.stats = this.stats;
            this.Hide();
        }

        private void StatsBtn_Click(object sender, EventArgs e)
        {
            this.stats.Show();
            this.stats.login = this.login;
            this.stats.order = this.order;
            this.stats.customer = this;
            this.stats.menu = this.menu;
            this.Hide();
        }

        private void Quantity_Click(object sender, EventArgs e)
        {

        }

        private void CitytxtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Pricelbl_Click(object sender, EventArgs e)
        {

        }

        private void foodnameLbl_Click(object sender, EventArgs e)
        {

        }
        SqlConnection cn = new SqlConnection(@"Data Source = DESKTOP-9GVJKN6; Initial Catalog = Jing; Integrated Security = True");
        private void Cusotmer_Load(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            SqlDataAdapter sda = new SqlDataAdapter(@"Select * from Customer", cn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            //open connection
            cn.Open();
            if (SearchTxtBox.Text=="")
            {
                try
                {
                    SqlDataAdapter sda = new SqlDataAdapter("Select * from Customer", cn);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch (Exception)
                {
                    MessageBox.Show("aa");
                }
                
            }
            if (SearchTxtBox.Text != "")
            {
                try
                {
                    SqlDataAdapter sda = new SqlDataAdapter("Select * from Customer where Customer_Id = " + SearchTxtBox.Text.Trim(), cn);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch (Exception)
                {
                    MessageBox.Show("Customer is not found!");
                }
            }
            cn.Close();
        }

        private void InsertBtn_Click(object sender, EventArgs e)
        {
            //open connection
            cn.Open();
            SqlCommand cmd = cn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            try
            {               
                cmd.CommandText = "insert into Customer values(" + idtxtbox.Text + ", '" + addtxtBox.Text + "', '" + CitytxtBox.Text + "', ' " + CustomerNameTextBox.Text + "', '" + PhoneTxtBox.Text + "' )";               
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {

                MessageBox.Show("Fail! Please add proper data!");
            }
            cn.Close();
            dispData();
        }
        public void dispData()
        {
            cn.Open();
            SqlCommand cmd = cn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from Customer";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            cn.Close();
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {

            cn.Open();
            SqlCommand cmd = cn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            try
            {
                cmd.CommandText = "Delete from Customer where Customer_Id=" + idtxtbox.Text;
                int x = cmd.ExecuteNonQuery();
                if (x==0)
                {
                    MessageBox.Show("No record is found!");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Fail! Please check if you enter correct customer ID! Or the customer has ordered, cannot be deleted!");
            }
            cn.Close();
            dispData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cn.Open();
            SqlCommand cmd = cn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            try
            {
                cmd.CommandText = "Update Customer set Address='" + addtxtBox.Text + "', City='" + CitytxtBox.Text + "',Customer_Name='" + CustomerNameTextBox.Text + "' ,Telephone=" + PhoneTxtBox.Text+ " where Customer_Id=" +idtxtbox.Text.Trim();
                int x = cmd.ExecuteNonQuery();

                if (x == 0)
                {
                    MessageBox.Show("No customer is found for updating!");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Fail! Please check if you enter correct customer ID!");
               
            }
            cn.Close();
            dispData();
        }
    }
}
