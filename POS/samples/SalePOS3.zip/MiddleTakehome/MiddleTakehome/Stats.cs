﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiddleTakehome
{
    public partial class Stats : Form
    {
        public Stats()
        {
            InitializeComponent();
        }
        public Order order;
        public Login login;
        public Menu menu;
        public Cusotmer customer;

        private void OrderBtn_Click(object sender, EventArgs e)
        {
            this.order.Show();
            this.order.customer = this.customer;
            this.order.menu = this.menu;
            this.order.login = this.login;
            this.order.stats = this;
            this.Hide();

        }

        private void CustomerBtn_Click(object sender, EventArgs e)
        {

            this.customer.Show();
            this.customer.order = this.order;
            this.customer.menu = this.menu;
            this.customer.login = this.login;
            this.customer.stats = this;
            this.Hide();
        }

        private void MenuBtn_Click(object sender, EventArgs e)
        {
            this.menu.Show();
            this.menu.order = this.order;
            this.menu.customer = this.customer;
            this.menu.stats = this;
            this.menu.login = this.login;
            this.Hide();
        }

        private void StatsBtn_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            this.login.Show();
            this.Hide();
        }

        private void Stats_Load(object sender, EventArgs e)
        {

        }
        class orderByCustomer {
            public int Customer_Id { get; set; }
            public string Customer_Name { get; set; }
            public int Order_Id { get; set; }
            public string order_Date { get; set; }
        }
        private void button1_Click(object sender, EventArgs e)
        {

            ReportDataContext dataContext = new ReportDataContext();
            try
            {
                int customer_ID = Convert.ToInt32(SearchIDTxtBox.Text.Trim().ToString());
                dataGridView1.DataSource = from Customer in dataContext.Customers
                                           join dboOrder in dataContext.dboOrders
                                           on Customer.Customer_Id equals dboOrder.Customer_Id
                                           where dboOrder.Customer_Id == customer_ID
                                           select new orderByCustomer
                                           {
                                               Customer_Id = Customer.Customer_Id,
                                               Customer_Name = Customer.Customer_Name,
                                               Order_Id = dboOrder.Order_Id,
                                               order_Date = dboOrder.Order_Date.ToString()
                                           };
            }
            catch (Exception)
            {
            }
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            ReportDataContext dataContext = new ReportDataContext();
            try
            {               
                dataGridView1.DataSource = from Customer in dataContext.Customers
                                           join dboOrder in dataContext.dboOrders
                                           on Customer.Customer_Id equals dboOrder.Customer_Id
                                           select new orderByCustomer
                                           {
                                               Customer_Id = Customer.Customer_Id,
                                               Customer_Name = Customer.Customer_Name,
                                               Order_Id = dboOrder.Order_Id,
                                               order_Date = dboOrder.Order_Date.ToString()
                                           };
            }
            catch (Exception)
            {
                
            }
            
        }

        private void SearchIDTxtBox_TextChanged(object sender, EventArgs e)
        {

        }
        public class OrderByProduct {
            public int product_id { get; set; }
            public string product_name { get; set; }
            public int remaining_quantity { get; set; }
            public int saled_quantity { get; set; }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            ReportDataContext dataContext = new ReportDataContext();
            dataGridView1.DataSource = from product in dataContext.Products
                                       join Order_Item in dataContext.Order_Items                                                    
                                       on   product.Product_Id equals Order_Item.Product_Id 
                                       into g
                                       select new {
                                           product_id = product.Product_Id,
                                           product_name = product.Product_Name,
                                           remaining_quantity = product.Product_Quantity,
                                           saled_quantity =g.Sum(p => (int?)p.Quantity) 
                                           
                                       };
        }

        private void search2btn_Click(object sender, EventArgs e)
        {
            ReportDataContext dataContext = new ReportDataContext();
            try
            {
                int product_ID = Convert.ToInt32(productidTxtBox.Text.Trim().ToString());
                dataGridView1.DataSource = from product in dataContext.Products
                                           join Order_Item in dataContext.Order_Items
                                           on product.Product_Id equals Order_Item.Product_Id
                                           into g
                                           where product.Product_Id == product_ID
                                           select new
                                           {
                                               product_id = product.Product_Id,
                                               product_name = product.Product_Name,
                                               remaining_quantity = product.Product_Quantity,
                                               saled_quantity = g.Sum(p => (int?)p.Quantity)

                                           };
            }
            catch (Exception)
            {

               
            }
           
        }
    }
}
