﻿using MiddleTakehome;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiddleTakehome
{
    public partial class Order : Form
    {
        
        public Order()
        {
            InitializeComponent();
        }
        public Login login;
        public Cusotmer customer;
        public Menu menu;
        public Stats stats;
        private void CustomerBtn_Click(object sender, EventArgs e)
        {
            
            
            this.customer.Show();
            this.customer.order = this;
            this.customer.menu = this.menu;
            this.customer.login = this.login;
            this.customer.stats = this.stats;
            this.Hide();
           
        }

        //Connect with database

        SqlConnection cn = new SqlConnection(@"Data Source = DESKTOP-9GVJKN6; Initial Catalog = Jing; Integrated Security = True");
        public void dispData()
        {
            //Fill Drinks Table
            cn.Open();
            SqlCommand cmd = cn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select Product_Id,Product_Name,Purchase_Price,Image from Product where Product_Category = 'Drinks' ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            cn.Close();
            //Fill dessert table
            cn.Open();
            SqlCommand cmd2 = cn.CreateCommand();
            cmd2.CommandType = CommandType.Text;
            cmd2.CommandText = "Select Product_Id,Product_Name,Purchase_Price,Image from Product where Product_Category = 'Dessert' ";
            cmd2.ExecuteNonQuery();
            DataTable dt2 = new DataTable();
            SqlDataAdapter sda2 = new SqlDataAdapter(cmd2);
            sda2.Fill(dt2);
            dataGridView2.DataSource = dt2;
            cn.Close();
        }
        public void dispCustomer() {
            cn.Open();
            SqlCommand sc = new SqlCommand("select Customer_Id, Customer_Name from Customer", cn);
            SqlDataReader reader;
            reader = sc.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("Customer_Id", typeof(int));
            dt.Columns.Add("Customer_Name", typeof(string));
            dt.Load(reader);
            CustomerDropbox.ValueMember = "Customer_Id";
            CustomerDropbox.DisplayMember = "Customer_Name";
            CustomerDropbox.DataSource = dt;
            cn.Close();
        }
        private void Order_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'jingDataSet.Product' table. You can move, or remove it, as needed.
            dispData();
            dispCustomer();

       
      
        }

        private void LogoutBtn_Click(object sender, EventArgs e)
        {
            login.Show();
            
            this.Hide();
        }

        private void MenuBtn_Click(object sender, EventArgs e)
        {
            this.menu.Show();
            this.menu.order = this;
            this.menu.customer = this.customer;
            this.menu.stats = this.stats;
            this.menu.login = this.login;
            this.Hide();
        }

        private void StatsBtn_Click(object sender, EventArgs e)
        {
            this.stats.Show();
            this.stats.login = this.login;
            this.stats.order = this;
            this.stats.customer = this.customer;
            this.stats.menu = this.menu;
            this.Hide();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void TotalLbl_Click(object sender, EventArgs e)
        {

        }

        int index;
        string selectedProduct_Id;
        string selectedProduct_Name;
        string selectedProduct_Price;
        private void AddToBtn_Click(object sender, EventArgs e)
        {
            try
            {
                //For drinks
                Int32 selectedRowCount1 = dataGridView1.Rows.GetRowCount(DataGridViewElementStates.Selected);
                if (selectedRowCount1 > 0)
                {
                    subtotal = 0;
                    index = dataGridView1.SelectedRows[0].Index;
                    //food id 
                    DataGridViewRow selectedRow = dataGridView1.Rows[index];
                    selectedProduct_Id = selectedRow.Cells[0].Value.ToString();
                    selectedProduct_Name = selectedRow.Cells[1].Value.ToString();
                    selectedProduct_Price = selectedRow.Cells[2].Value.ToString();
                    //Add to oderDatagridview
                    datagridviewOrder.Rows.Add(selectedProduct_Id ,selectedProduct_Name, selectedProduct_Price, 1);
                }
                //For Dessert
                Int32 selectedRowCount2 = dataGridView2.Rows.GetRowCount(DataGridViewElementStates.Selected);
                if (selectedRowCount2 > 0)
                {
                    subtotal = 0;
                    index = dataGridView2.SelectedRows[0].Index;
                    //food id 
                    DataGridViewRow selectedRow = dataGridView2.Rows[index];
                    selectedProduct_Id = selectedRow.Cells[0].Value.ToString();
                    selectedProduct_Name = selectedRow.Cells[1].Value.ToString();
                    selectedProduct_Price = selectedRow.Cells[2].Value.ToString();
                    //Add to oderDatagridview
                    datagridviewOrder.Rows.Add(selectedProduct_Id ,selectedProduct_Name, selectedProduct_Price, 1);
                }
                caluclate();
            }
            catch (Exception)
            {
            }
            
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            try
            {
                Int32 selectedRowCount = datagridviewOrder.Rows.GetRowCount(DataGridViewElementStates.Selected);
                if (selectedRowCount > 0)
                {
                    subtotal = 0;
                    index = datagridviewOrder.SelectedRows[0].Index;
                    //food id 
                    DataGridViewRow selectedRow = datagridviewOrder.Rows[index];
                    int quantity = Convert.ToInt32(selectedRow.Cells[3].Value.ToString());
                    quantity++;                 
                    selectedRow.Cells[3].Value = quantity;
                    caluclate();
                }
               
            }
            catch (Exception)
            {
               
            }

        }

        private void ReduceBtn_Click(object sender, EventArgs e)
        {
            try
            {
                Int32 selectedRowCount = datagridviewOrder.Rows.GetRowCount(DataGridViewElementStates.Selected);
                if (selectedRowCount > 0)
                {
                    subtotal = 0;
                    index = datagridviewOrder.SelectedRows[0].Index;
                    //food id 
                    DataGridViewRow selectedRow = datagridviewOrder.Rows[index];
                    int quantity = Convert.ToInt32(selectedRow.Cells[3].Value.ToString());
                    quantity--;
                    if (quantity==0)
                    {
                     
                        datagridviewOrder.Rows.RemoveAt(index);
                    }
                    else
                    {
                        selectedRow.Cells[3].Value = quantity;
                    }
                    caluclate();
                }
               
            }
            catch (Exception)
            {

            }
           
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                Int32 selectedRowCount = datagridviewOrder.Rows.GetRowCount(DataGridViewElementStates.Selected);
                if (selectedRowCount > 0)
                {
                    subtotal = 0;
                    index = datagridviewOrder.SelectedRows[0].Index;
                    datagridviewOrder.Rows.RemoveAt(index);
                    caluclate();
                }
             
            }
            catch (Exception)
            {

            }
            
        }
        double subtotal = 0;
        double tax = 0;
        double total = 0;
        double price ;
        int  quantity;
        double price2;
        public void caluclate() {
            
                foreach (DataGridViewRow row in datagridviewOrder.Rows)
                {
                if (row.Cells["Purchase_Price"].Value != null)
                {
                    price = Convert.ToDouble(row.Cells["Purchase_Price"].Value.ToString());
                }
                if (row.Cells["Quantity"].Value != null)
                {
                    quantity = Convert.ToInt32(row.Cells["Quantity"].Value.ToString());
                }
                if (row.Cells["Purchase_Price"].Value != null && row.Cells["Quantity"].Value != null)
                {
                    subtotal = subtotal + (price * quantity);
                }                   
                
                }
                tax = subtotal * 0.13;
                total = subtotal + tax;
                SubtotalLbl.Text = subtotal.ToString();
                TaxLbl.Text = tax.ToString();
                TotalLbl.Text = total.ToString();
        
        }

        private void PayBtn_Click(object sender, EventArgs e)
        {
            //Open connection with database
            cn.Open();
            //Getting the max order _ID
            SqlCommand sc = new SqlCommand("select max(Order_Id) as max_id from Orders", cn);
            int max_order_Id = (int)sc.ExecuteScalar();
            //Insert Order to Orders table
            int order_Id = max_order_Id + 1;
            DateTime order_Date = DateTime.Now;
            int customer_Id = (int)CustomerDropbox.SelectedValue;
            sc.CommandText = "insert into Orders values(" + order_Id + ", '" + order_Date + "', " + customer_Id + ")";
         
            sc.ExecuteNonQuery();
            //Getting the max Item_Id in order_Item_Table
            SqlCommand sc1= new SqlCommand("select max(Item_Id) as max_id from Order_Item", cn);
            int max_item_Id = (int)sc1.ExecuteScalar();
            //Insert Order_Item to Order_Item table
            int item_Id = max_item_Id + 1;
          
            foreach (DataGridViewRow row in datagridviewOrder.Rows)
            {
                if (row.Cells["Purchase_Price"].Value != null) {
                   
                    sc1.CommandText = "insert into Order_Item values(" + item_Id + ", " + order_Id + ", "+ Convert.ToInt32(row.Cells["FoodID"].Value.ToString()) +", " + Convert.ToInt32(row.Cells["Quantity"].Value.ToString()) + ")";
                   
                    item_Id++;
                    sc1.ExecuteNonQuery();
                }
               
                
            }
            //Update the Quantity saved in Product Table
            foreach (DataGridViewRow row in datagridviewOrder.Rows)
            {
                if (row.Cells["Purchase_Price"].Value != null)
                {
                    int product_id = Convert.ToInt32(row.Cells["FoodID"].Value.ToString());
                    int deleting_quantity= Convert.ToInt32(row.Cells["Quantity"].Value.ToString());

                    sc1.CommandText = "update Product set Product.Product_Quantity = Product_Quantity - "+deleting_quantity+" where Product.Product_Id = "+product_id+";";
                    sc1.ExecuteNonQuery();                  
                }
            }
            if ( datagridviewOrder.Rows.Count>1)
            {
                MessageBox.Show("Order Succesfuly!");
            }
            cn.Close();
            //Emtpy all the order item
           
            datagridviewOrder.Rows.Clear();

        }

        private void CustomerDropbox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
